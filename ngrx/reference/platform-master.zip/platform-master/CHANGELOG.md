# Changelogs

- [@ngrx/store](./modules/store/CHANGELOG.md)  
- [@ngrx/effects](./modules/effects/CHANGELOG.md)  
- [@ngrx/router-store](./modules/router-store/CHANGELOG.md)  
- [@ngrx/store-devtools](./modules/store-devtools/CHANGELOG.md)
- [@ngrx/entity](./modules/entity/CHANGELOG.md)
- [@ngrx/schematics](./modules/schematics/CHANGELOG.md)
