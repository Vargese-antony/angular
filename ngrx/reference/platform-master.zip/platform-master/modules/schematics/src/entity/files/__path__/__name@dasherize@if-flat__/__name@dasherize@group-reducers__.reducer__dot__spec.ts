import { reducer, initialState } from '<%= featurePath(group, flat, "reducers", dasherize(name)) %><%= dasherize(name) %>.reducer';

describe('<%= classify(name) %> Reducer', () => {
  describe('unknown action', () => {
    it('should return the initial state', () => {
      const action = {} as any;

      const result = reducer(initialState, action);

      expect(result).toBe(initialState);
    });
  });
});
