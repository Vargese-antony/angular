export interface <%= classify(name) %> {
  id: string;
}
