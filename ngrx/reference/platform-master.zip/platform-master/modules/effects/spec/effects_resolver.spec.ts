import 'rxjs/add/observable/of';
import { Observable } from 'rxjs/Observable';
import { Effect, mergeEffects } from '../';

describe('mergeEffects', () => {});
