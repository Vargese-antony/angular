/* Defines the user entity */
export interface IUser {
    id: number;
    userName: string;
    isAdmin: boolean;
}
